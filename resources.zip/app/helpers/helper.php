<?php

use App\Models\Client;
use App\Models\Course;
use App\Models\Employee;

function getClientById($client_id=0){
    $client = Client::where('id', $client_id)->first();
    return $client;
}

function getCourseById($course_id=0){
    $course = Course::where('id', $course_id)->first();
    return $course;
}

function getCountEmployees($client_id=0){
    return Employee::where('client_id', $client_id)->count();
}