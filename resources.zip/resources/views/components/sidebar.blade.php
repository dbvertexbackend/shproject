  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="{{ URL::asset('assets/user.png')}}" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>{{auth()->user()->first_name." ".(auth()->user()->last_name)}}</p>
          <a href=""><i class="fa fa-circle text-success"></i> Admin</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
         <li class="{{Request::segment(1)=='dashboard'?'active':''}}">
          <a href="{{route('dashboard')}}">
            <i class="fa fa-th"></i> <span>Dashbaord</span>
          </a>
        </li>
        <li class="{{Request::segment(1)=='users'?'active':''}}">
          <a href="{{route('users')}}">
            <i class="fa fa-users"></i> <span>Users</span>
          </a>
        </li>
        <li class="{{Request::segment(1)=='clients'?'active':''}}">
          <a href="{{route('clients')}}">
            <i class="fa fa-address-book"></i> <span>Clients</span>
          </a>
        </li>
        @if (Request::segment(1)=='employees')
        <li class="{{Request::segment(1)=='employees'?'active':''}}">
          <a href="{{route('employees', Request::segment(2))}}">
            <i class="fa fa-group"></i> <span>Employees</span>
          </a>
          </li>
        @endif
        
        <li class="{{Request::segment(1)=='courses'?'active':''}}">
          <a href="{{route('courses')}}">
            <i class="fa fa-book"></i> <span>Courses</span>
          </a>
        </li>
        <li class="{{Request::segment(1)=='attendance'?'active':''}}">
          <a href="">
            <i class="fa fa-clock-o"></i> <span>Attendance</span>
          </a>
        </li>
        <li class="{{Request::segment(1)=='generatecertificate'?'active':''}}">
          <a href="">
            <i class="fa fa-certificate"></i> <span>Generate Certificate</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>