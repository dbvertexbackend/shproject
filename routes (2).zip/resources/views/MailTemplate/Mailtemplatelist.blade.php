<TextArea rows="12" type="text" name="email_body" id="email_body" class="email_body form-control" placeholder="email_body">{{$invite_temp->template}}</TextArea>    
                                        
<script type="text/javascript">
    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
</script>