@include("components/header")
@include("components/sidebar")
<style>
    .offsetbox{
        margin-left:50%;
        transform:translatex(-50%);
     }

      @media only screen and (max-width: 600px) {
        .offsetbox{
            margin-left:0%;
            transform:translatex(0%);
        }
      }
     
      .err_text{
          color:red;
      }
   </style>   
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Event Invitation
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">event invitation</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div class="container">
                 <form action="{{route('addeventpost')}}" enctype='multipart/form-data'  id="handleform" method="post">
                     @csrf
                     <input type="hidden" name="course_id" value="">
                    <div class="row">
                        <div class="col-md-4">
                           <div class="row">
                               <div class="col-md-12">
                                    <span><b>Client Name :</b> {{$course_client->name}} </span>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-md-12">
                                    <span><b>Client Email :</b> {{$course_client->email}} </span>
                               </div>
                           </div>
                        </div>
                        <div class="col-md-4">
                            <div class="row">
                               <div class="col-md-12">
                                    <span><b>Consultant Name :</b> {{$course_consultant->first_name." ".$course_consultant->last_name}} </span>
                               </div>
                           </div>
                           <div class="row">
                               <div class="col-md-12">
                                    <span><b>Consultant Email :</b> {{$course_consultant->email}} </span>
                               </div>
                           </div>
                        </div>
                        <div class="col-md-3">
                            <div class="row">  
                            <div class="col-md-12">
                               <label>Select employees</label>
                               <select class="form-control 4colactive" id="employees_select" name="multicheckbox[]" multiple="multiple">
                                   @foreach ($course_employees as $key => $employee)
                                       <option value="{{$employee->id}}">{{$employee->firstname." ".$employee->lastname}}</option>
                                   @endforeach
                               </select>  
                               </div>  
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offsetbox">
                                <div class="row">
                                   <div class="form-group">
                                       <label for="" class="labelheading">CC </label>
                                       <input type="text" name="email_cc" id="email_cc" class="email_cc form-control" placeholder="Email CC">
                                   </div>
                               </div>
                               <div class="row">
                                   <div class="form-group">
                                       <label for="" class="labelheading">BCC </label>
                                       <input type="text" name="email_bcc" id="email_bcc" class="email_bcc form-control" placeholder="Email BCC">
                                   </div>
                               </div>
                               <div class="row">
                                   <div class="form-group">
                                       <label for="" class="labelheading">Subject</label>
                                       <input type="text" name="email_subject" id="email_subject" class="email_subject form-control" placeholder="Email Subject">
                                   </div>
                               </div>
                               <div class="row">
                                   <div class="form-group">
                                       <label for="" class="labelheading">Select Template</label>
                                       <select id="templateselect" class="form-control">
                                           <option value=""> --- Select Template -- </option>
                                            @foreach ($inviteTypes as $inviteType)
                                                <option value="{{$inviteType->id}}">{{$inviteType->name}}</option>
                                            @endforeach
                                        </select>   
                                        <div id="rendertemplate">
                                        
                                        </div>     
                                        <a href="" id="edittembtn" class="btn btn-primary">Edit template</a>
                                    </div>
                               </div>
                               <div class="row">
                                    <input type="submit" id="formbtn" class="btn btn-primary" value="Send">
                               </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

 @include("components.script")

<script>
$('select[multiple]').multiselect({
    columns: 2,
    selectAll : true,
    placeholder: 'Select employees'
});
</script>
<script>
  $(function () {

   
    $(".js-example-tokenizer").select2({
    tags: true,
    tokenSeparators: [',', ' ']
    })

    $("#edittembtn").hide();
    $("#templateselect").change(function (e) { 
        let template_id = $("#templateselect").val();
        if(template_id==""){
        $("#rendertemplate").empty();
        $("#edittembtn").hide();
        return false;
        }
        $("#edittembtn").show();
        $("#edittembtn").attr("href", "{{URL::to('/')}}/edittemplate/"+template_id);
        e.preventDefault();
        $.ajax({
        type: "post",
        url: "{{route('createinvitationtemplateapi')}}",
        data: {course_id :<?=$course->id?>, template_id : template_id },
        dataType: "text",
        success: function (response) {
            $("#rendertemplate").html(response);
        }
        });
    });
    

   
    $("#handleform").submit(function(){
        $("#formbtn").prop("disabled", true);
        $("#formbtn").val("Sending...");
        var is_validate = false;
        let employees = $("#employees_select").val().join(',');
        if(employees==""){
            alert("please select atleast one employee");
            $("#formbtn").val("Send");
                $("#formbtn").prop("disabled", false);
            return false;
        }
        let template_id = $("#templateselect").val();
        if(template_id=="")
        alert("please select template");
        let email_cc = $("#email_cc").val();
        let email_bcc = $("#email_bcc").val();
        let email_subject = $("#email_subject").val();

        console.log(template_id);
        $.ajax({
            type: "post",
            url: "{{route('sendinvitationapi')}}",
            data: {course_id:<?=$course->id?>, employees:employees, template_id:template_id, email_cc:email_cc, email_bcc:email_bcc, email_subject:email_subject},
            dataType: "json",
            success: function (response) {
                alert("Email successfully sent to employee email id.");
                // swal("Email Sent", "Email successfully sent to employee email id.", "success");
            },
            error:function(){
                
            },
            complete: function(){
                $("#formbtn").val("Send");
                $("#formbtn").prop("disabled", false);
                swal("Email Sent", "Email successfully sent to employee email id.", "success");
            }
        });
        return is_validate;
    })

    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
  <!-- /.content-wrapper -->
  @include("components.footer")
</body>
</html>
