<?php echo $__env->make("components/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("components/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/loginpage/#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Courses</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <?php if(isset($client_id)&&!empty($client_id)): ?>
              <a href="<?php echo e(route('addclientcourse', $client_id)); ?>" class="float-r"><button class="btn float-right btn-primary">Add Courses</button></a>
              <?php endif; ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x:auto">
              <table id="example2" class="table table-bordered table-hover table-striped">
                <thead>
                <tr>
                  <th>Sr.</th>
                  <th>Course Name</th>
                  <th>Consultant</th>
                  <th>Start Date & Time</th>
                  <th>End Date & Time</th>
                  <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="serialnumberRow"><?php echo e(($key+1)); ?></td>
                  <td><a href="<?php echo e(route('attendances', $course->id)); ?>"><?php echo e($course->name); ?></a></td>
                  <td><?php echo e(getusername($course->consultant_id)); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($course->start_date.' '.$course->start_time))); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($course->end_date.' '.$course->end_time))); ?></td>
                  <td class="ActionBtnRow"><a class="linktxt" href="<?php echo e(route('deleteclientcourse', $course->id)); ?>"><button class="btn btn-danger">Delete</button></a></td>
                </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php echo $__env->make("components.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make("components.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
<?php /**PATH E:\laravel\shproject\resources\views/Clientcourse/clientCourses_list.blade.php ENDPATH**/ ?>