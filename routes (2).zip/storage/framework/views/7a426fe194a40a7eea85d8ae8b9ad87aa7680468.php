<?php echo $__env->make("components/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("components/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Clients
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Clients</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
                <a href="<?php echo e(route('addclient')); ?>" class="float-r"><button class="btn btn-primary">Add Client</button></a>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x:auto">
              <table id="example2" class="table table-bordered table-hover table-striped ">
                <thead>
                <tr>
                  <th class="serialnumberRow">Sr.</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th class="empoloyeeCountRowClient">Management Counts</th>
                  <th class="actionBtnRowClients">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e(($key+1)); ?></td>
                  <td><a href="<?php echo e(route('clientcourses', $client->id)); ?>"><?php echo e($client->name); ?></a></td>
                  <td><?php echo e($client->email); ?></td>
                  <td><?php echo e(getCountEmployees($client->id)); ?></td>
                  <td>
                    <a href="<?php echo e(route('addevent', $client->id)); ?>"><button class="btn btn-primary">Create Event</button></a>
                    <a href="<?php echo e(route('deleteclient', $client->id)); ?>"><button class="btn btn-danger">Delete</button></a>
                  </td>
                </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php echo $__env->make("components.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!-- jQuery 3 -->
 <?php echo $__env->make("components.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
<?php /**PATH E:\laravel\shproject\resources\views/Clients/clients_list.blade.php ENDPATH**/ ?>