<?php echo $__env->make("components/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("components/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Attendance
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Attendance</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
               <h4><b>User</b> : <?php echo e($user->firstname." ".$user->lastname); ?> </h4>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x:auto">
              <table id="example2" class="table table-bordered table-hover table-striped ">
                <thead>
                <tr>
                  <th class="serialnumberRow">Sr.</th>
                  <th>Date</th>
                  <th class="empoloyeeCountRowClient">Client Name</th>
                  <th class="actionBtnRowClients">Attendance</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e(date("d M, Y", strtotime($period))); ?></td>
                    <td><?php echo e(getclientname($course->client_id)); ?></td>
                    <td>
                        <?php
                        $myattendance = getuserattendance(date('Y-m-d', strtotime($period)), $user->id, $course->id);
                        ?>
                        <select data-userid="<?php echo e($user->id); ?>" data-dateof="<?php echo e(date('Y-m-d', strtotime($period))); ?>" class="makeattendance form-control">
                            <option value="">--Select Attendance--</option>
                            <option value="1" <?php echo e(($myattendance&&($myattendance->attendance==1))?'selected':''); ?>>Present</option>
                            <option value="2" <?php echo e(($myattendance&&($myattendance->attendance==2))?'selected':''); ?>>Absent</option>
                            <option value="3" <?php echo e(($myattendance&&($myattendance->attendance==3))?'selected':''); ?>>Delayed</option>
                        <select>    
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php echo $__env->make("components.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!-- jQuery 3 -->
 <?php echo $__env->make("components.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })

    $(document).on("change", ".makeattendance", function (e) { 
        e.preventDefault();
        let attend_date = $(this).data("dateof");
        let attendance = $(this).val();
        let url = "<?php echo e(route('attendanceapi')); ?>";
        if(attendance=='')
            url="<?php echo e(route('deleteuserattendanceapi')); ?>";
        let user_id = $(this).data("userid");
        $.ajax({
            type: "post",
            url: url,
            data: {"course_id":<?php echo e($course->id); ?>, "attend_date":attend_date, "attendance":attendance, "user_id":user_id},
            dataType: "dataType",
            success: function (response) {
                
            }
        });
    });
  })
</script>
</body>
</html>
<?php /**PATH E:\laravel\shproject\resources\views/Attendances/alltendance_details.blade.php ENDPATH**/ ?>