<?php echo $__env->make("components/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("components/sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Events
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Events</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
            <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#upcoming">Upcoming</a></li>
            <li><a data-toggle="tab" href="#inprogress">Inprogress</a></li>
            <li><a data-toggle="tab" href="#completed">Completed</a></li>
            </ul>
            </div>
            <!-- /.box-header -->
            <div class="box-body" style="overflow-x:auto">
            <div class="tab-content">
            <div id="upcoming" class="tab-pane fade in active">
            <table class="example2 table table-bordered table-hover table-striped">
                <thead>
                <tr>
                <th>Sr.</th>
                  <th>Client Name</th>
                  <th>Consultant</th>
                  <th>Course</th>
                  <th>No. of Employees</th>
                  <th>Start Date Time</th>
                  <th>End Date Time</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $upcoming_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="serialnumberRow"><?php echo e(($key+1)); ?></td>
                  <td><?php echo e(getclientname($event->client_id)); ?></td>
                  <td><?php echo e(getUserById($event->consultant_id)->first_name." ".getUserById($event->consultant_id)->last_name); ?></td>
                  <td><?php echo e($event->name); ?></td>
                  <td><?php echo e(getCountEmployeesOfCourse($event->id)); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($event->start_date))); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($event->end_date))); ?></td>
                  <td class="ActionBtnRow"><a class="linktxt" href="<?php echo e(route('inviteforevent', $event->id)); ?>"><button class="btn btn-primary">Invite</button></a></td>
                </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div id="inprogress" class="tab-pane fade">
            <table class="example2 table table-bordered table-hover table-striped">
                <thead>
                <tr>
                  <th>Sr.</th>
                  <th>Client Name</th>
                  <th>Consultant</th>
                  <th>Course</th>
                  <th>No. of Employees</th>
                  <th>Start Date Time</th>
                  <th>End Date Time</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $inprogress_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="serialnumberRow"><?php echo e(($key+1)); ?></td>
                  <td><?php echo e($event->client_id); ?></td>
                  <td><?php echo e($event->consultant_id); ?></td>
                  <td><?php echo e($event->name); ?></td>
                  <td><?php echo e(getCountEmployeesOfCourse($event->id)); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($event->start_date))); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($event->end_date))); ?></td>
                  <td class="ActionBtnRow"><a class="linktxt" href="<?php echo e(route('deleteevent', $event->id)); ?>"><button class="btn btn-danger">Delete</button></a></td>
                </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div id="completed" class="tab-pane fade">
            <table class="example2 table table-bordered table-hover table-striped">
                <thead>
                <tr>
                  <th>Sr.</th>
                  <th>Client Name</th>
                  <th>Consultant</th>
                  <th>Course</th>
                  <th>No. of Employees</th>
                  <th>Start Date Time</th>
                  <th>End Date Time</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $completed_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="serialnumberRow"><?php echo e(($key+1)); ?></td>
                  <td><?php echo e($event->client_id); ?></td>
                  <td><?php echo e($event->consultant_id); ?></td>
                  <td><?php echo e($event->name); ?></td>
                  <td><?php echo e(getCountEmployeesOfCourse($event->id)); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($event->start_date))); ?></td>
                  <td><?php echo e(date("d M, Y h:i A", strtotime($event->end_date))); ?></td>
                  <td class="ActionBtnRow"><a class="linktxt" href="<?php echo e(route('deleteevent', $event->id)); ?>"><button class="btn btn-danger">Delete</button></a></td>
                </tr>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <?php echo $__env->make("components.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->make("components.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('.example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
<?php /**PATH E:\laravel\shproject\resources\views/events/event_list.blade.php ENDPATH**/ ?>