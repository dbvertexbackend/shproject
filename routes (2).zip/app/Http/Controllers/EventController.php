<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Employee;
use App\Models\Course;
use App\Models\Clientcourse;
use App\Models\Mailtemplate;
use Illuminate\Http\Request;
use DB;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $upcoming_events = Clientcourse::where('start_date', '>', date("Y-m-d H:i:s"))->get();
        $inprogress_events = Clientcourse::where('start_date', '<', date("Y-m-d H:i:s"))->where('end_date', '>', date("Y-m-d H:i:s"))->get();
        $completed_events = Clientcourse::where('end_date', '<', date("Y-m-d H:i:s"))->get();
        return view("events.event_list")->with(["upcoming_events"=>$upcoming_events, "inprogress_events"=>$inprogress_events, "completed_events"=>$completed_events]);
    }

    public function inviteforevent($course_id=0){
        if($course_id==0)
        die();
        $course = Clientcourse::where('id', $course_id)->first();
        $course_client = getClientById($course->client_id);
        $course_consultant = getUserById($course->consultant_id);
        $course_employees = Employee::where('course_id', $course_id)->get();
        $invite_temp = Mailtemplate::where('name', 'invites')->first();
        $inviteTypes = Mailtemplate::select('id', 'name')->get();
        return view('events.inviteforevent', ["course"=>$course, "course_client"=>$course_client, "course_consultant"=>$course_consultant, "course_employees"=>$course_employees, "invite_temp"=>$invite_temp, "inviteTypes"=>$inviteTypes]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($client_id=0)
    {
        if($client_id!=0){
        $employess = Employee::all();
        $consultants = Employee::all();
        $courses = Course::all();
        return view("events.addEvent")->with(["client_id"=>$client_id, "employess"=>$employess, "consultants"=>$consultants, "courses"=>$courses]);
        }    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data["event_name"] = $request->event_name;
        $data["course_id"] = $request->course;
        $data["employees"] = $request->employees;
        $data["client_id"] = $request->client_id;
        $data["start_date"] = $request->start_date;
        $data["end_date"] = $request->end_date;
        $data["consulatant_id"] = $request->consultant;
        $result = Event::insert($data);
        if($result)
        return redirect()->route('events')
            ->with('success','You have successfully add event.');
    }
    
    function sendInviteMail($to="", $subject="", $cc="", $bcc="", $content=""){
        $details = [
            'title' => $subject,
            'body' => $content,
            'cc' => $cc,
            'bcc' => $bcc
        ];
        try{
        return \Mail::to($to)->send(new \App\Mail\InviteMail($details));
        }
        catch(\Exception $e){
            return $e;
        }
    }

    public function sendinvitation(Request $req){
        $course_id = $req->course_id;
        $employees = $req->employees;
        $template_id = $req->template_id;
        $email_cc = $req->email_cc;
        $email_bcc = $req->email_bcc;
        $email_subject = $req->email_subject;
        // $employees = "10";
        // $course_id = 14;
        // $template_id = 1;
        if(!isset($employees)||empty($employees))
        return false;
        $employees_arr = explode(',', $employees);

        $course = Clientcourse::where('id', $course_id)->first();

        $temp = Mailtemplate::where('id', $template_id)->first();
        $template = $temp->template;

        $fdate = $course->start_date;
        $tdate = $course->end_date;
        $datetime1 = new \DateTime($fdate);
        $datetime2 = new \DateTime($tdate);
        $interval = $datetime1->diff($datetime2);
        $days_interval = $interval->format('%a');
        $days_interval = ($days_interval==1)?"$days_interval day":"$days_interval days";

        $template = str_replace('__COURSEDURATION__', $days_interval, $template); 
        $template = str_replace('__STARTDATE_', $fdate, $template); 
        $template = str_replace('__ENDDATE__', $tdate, $template); 
        $template = str_replace('__TIMING__', $course->start_time." ".$course->end_time, $template); 
        $template = str_replace('__LANGUAGEOFMATERIAL__', $course->language_of_material, $template); 
        $template = str_replace('__LANGUAGEOFFACILITATION_', $course->language_of_facilates, $template); 
        $template = str_replace('__TYPEOFCLASS__', $course->training_type, $template); 
        $template = str_replace('__LOCATION__', $course->city, $template); 
        $template = str_replace('__COURSENAME__', $course->name, $template);
        $template = str_replace('__INSTRUCTOR__', getusername($course->consultant_id), $template); 

        foreach ($employees_arr as $key => $employeeId) {
             $employee = Employee::where('id', $employeeId)->first();
             $template = str_replace('__EMPLOYEENAME__', $employee->firstname." ".$employee->lastname, $template);
             $this->sendInviteMail($employee->email, $email_subject, $email_cc, $email_bcc, $template);
        }
        echo "Success";
    }

    public function createinvitation(Request $req){
        $template_id = $req->template_id;
        $course_id = $req->course_id;

        $course = Clientcourse::where('id', $course_id)->first();

        $temp = Mailtemplate::where('id', $template_id)->first();
        $template = $temp->template;

        $fdate = $course->start_date;
        $tdate = $course->end_date;
        $datetime1 = new \DateTime($fdate);
        $datetime2 = new \DateTime($tdate);
        $interval = $datetime1->diff($datetime2);
        $days_interval = $interval->format('%a');
        $days_interval = ($days_interval==1)?"$days_interval day":"$days_interval days";

        $template = str_replace('__COURSEDURATION__', $days_interval, $template); 
        $template = str_replace('__STARTDATE_', $fdate, $template); 
        $template = str_replace('__ENDDATE__', $tdate, $template); 
        $template = str_replace('__TIMING__', $course->start_time." ".$course->end_time, $template); 
        $template = str_replace('__LANGUAGEOFMATERIAL__', $course->language_of_material, $template); 
        $template = str_replace('__LANGUAGEOFFACILITATION_', $course->language_of_facilates, $template); 
        $template = str_replace('__TYPEOFCLASS__', $course->training_type, $template); 
        $template = str_replace('__LOCATION__', $course->city, $template); 
        $template = str_replace('__COURSENAME__', $course->name, $template);
        $template = str_replace('__INSTRUCTOR__', getusername($course->consultant_id), $template);

        return response($template, 200)->header('Access-Control-Allow-Headers', '*');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function edit(Event $event)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Event $event)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy($event_id=0)
    {
        $result = Event::where('id', $event_id)->delete();
        if($result)
        return redirect()->back()
            ->with('success','You have successfully deleted event.');
    }
}
