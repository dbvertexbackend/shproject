<?php

namespace App\Http\Controllers;

use App\Models\Coursecronjob;
use Illuminate\Http\Request;

class CoursecronjobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Coursecronjob  $coursecronjob
     * @return \Illuminate\Http\Response
     */
    public function show(Coursecronjob $coursecronjob)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Coursecronjob  $coursecronjob
     * @return \Illuminate\Http\Response
     */
    public function edit(Coursecronjob $coursecronjob)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Coursecronjob  $coursecronjob
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Coursecronjob $coursecronjob)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Coursecronjob  $coursecronjob
     * @return \Illuminate\Http\Response
     */
    public function destroy(Coursecronjob $coursecronjob)
    {
        //
    }
}
