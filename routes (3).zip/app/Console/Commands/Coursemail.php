<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Coursecronjob;
use App\Models\Mailtemplate;

class Coursemail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'coursemail:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command is used to send scheduled invitation, invitation and Thanks you mail scheduled at the time of send invitation.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        \Log::info("Cron is working fine!");
        $cronjobs = Coursecronjob::where('schedule_time', date("Y-m-d H:i:00"));
        foreach ($cronjobs as $key => $cronjob) {
            if($cronjob->email_employees=="")
            continue;
            $employees_arr = explode(',', $cronjob->email_employees);
            $template = $cronjob->email_body;
            foreach ($employees_arr as $key => $employeeId) {
                $employee = Employee::where('id', $employeeId)->first();
                $template = str_replace('__EMPLOYEENAME__', $employee->firstname." ".$employee->lastname, $template);
                $course = Clientcourse::where('id', $cronjob->course_id)->first();
                $client = Client::where('id', $course->client_id)->first();
                Mailtemplate::sendMail($employee->email, $cronjob->email_subject, $cronjob->email_cc, $cronjob->email_bcc, $template, $client->name, $client->profile_pic);
            }
        }
        return 0;
    }
}
