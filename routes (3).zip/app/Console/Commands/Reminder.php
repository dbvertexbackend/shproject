<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Clientcourse;
use App\Models\Employee;
use App\Models\Mailtemplate;

class Reminder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'reminder:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $courses = Clientcourse::whereDate('start_date', date('Y-m-d', strtotime(date('Y-m-d')." -1 day")))->get();
        foreach ($courses as $key => $course) {
            $employees = Employee::where('course_id', $course->id)->get();
            $template =  Mailtemplate::where('name', 'invite')->first();
            foreach ($employees as $key => $employee) {
                $course = Clientcourse::where('id', $course->id)->first();
                $client = Client::where('id', $course->client_id)->first();
                Mailtemplate::sendMail($employee->email, "Reminder Mail.", "", "", $template, $client->name, $client->profile_pic);
            }
        }
        return 0;
    }
}
