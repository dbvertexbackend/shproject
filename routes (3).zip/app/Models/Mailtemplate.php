<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mailtemplate extends Model
{
    use HasFactory;

    public static function CourseTemplate($template_id=0, $course_id=0)
    {
        $course = Clientcourse::where('id', $course_id)->first();
        $temp = Mailtemplate::where('id', $template_id)->first();
        $template = $temp->template;

        $fdate = date("d M, Y", strtotime($course->start_date));
        $tdate = date("d M, Y", strtotime($course->end_date));
        $datetime1 = new \DateTime($fdate);
        $datetime2 = new \DateTime($tdate);
        $interval = $datetime1->diff($datetime2);
        $days_interval = $interval->format('%a');
        $days_interval = ($days_interval==1)?"$days_interval day":"$days_interval days";
        $timing = date("h:i a", strtotime($course->start_time))." - ".date("h:i a", strtotime($course->end_time));

        $template = str_replace('__COURSEDURATION__', $days_interval, $template); 
        $template = str_replace('__STARTDATE_', $fdate, $template); 
        $template = str_replace('__ENDDATE__', $tdate, $template); 
        $template = str_replace('__TIMING__', $timing, $template); 
        $template = str_replace('__LANGUAGEOFMATERIAL__', $course->language_of_material, $template); 
        $template = str_replace('__LANGUAGEOFFACILITATION_', $course->language_of_facilates, $template); 
        $template = str_replace('__TYPEOFCLASS__', $course->training_type, $template); 
        $template = str_replace('__LOCATION__', $course->city, $template); 
        $template = str_replace('__COURSENAME__', $course->name, $template);
        $template = str_replace('__REGISTRATIONLINK__', '<a hrerf="'.$course->calender_link.'">'.$course->registration_link.'</a>', $template);
        $template = str_replace('__WORKSHOPLINK__', '<a hrerf="'.$course->calender_link.'">'.$course->workshop_link.'</a>', $template);
        $template = str_replace('__INFOSHEETLINK__', '<a hrerf="'.$course->calender_link.'">'.$course->infosheet_link.'</a>', $template);
        $template = str_replace('__CALENDERLINK__', '<a hrerf="'.$course->calender_link.'">'.$course->calender_link.'</a>', $template);
        $template = str_replace('__INSTRUCTOR__', getusername($course->consultant_id), $template);
        return $template;
    }

    public static function sendMail($to="", $subject="", $cc="", $bcc="", $content="", $client_name="",  $client_profile=""){
        $details = [
            'title' => $subject,
            'body' => $content,
            'cc' => $cc,
            'bcc' => $bcc,
            'client_name' => $client_name,
            'client_profile' => $client_profile
        ];
        echo $to;
         \Mail::to($to)
                    ->cc($cc)
                    ->bcc($bcc)->send(new \App\Mail\InviteMail($details));
        
            if (\Mail::failures()) {
                return \Mail::failures();
                // return response showing failed emails
            }
            else{
                return true;
            }
    }
}
