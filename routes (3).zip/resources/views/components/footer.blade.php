  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.18
    </div>
    <strong>Copyright &copy; 2021-22 <a href="https://www.viftraining.com/">VIF Training & Consultant</a>.</strong> All rights
    reserved.
  </footer>