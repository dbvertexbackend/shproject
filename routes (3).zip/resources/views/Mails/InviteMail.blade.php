<img style="height:100px" src="{{$data['client_profile']}}"><br>
<span>Client Name : {{$data['client_name']}}</span><br>
{!! $data['body'] !!}