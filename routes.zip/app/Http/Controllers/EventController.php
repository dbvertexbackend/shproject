<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Employee;
use App\Models\Course;
use Illuminate\Http\Request;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $upcoming_events = Event::where('start_date', '>', date("Y-m-d H:i:s"))->get();
        $inprogress_events = Event::where('start_date', '<', date("Y-m-d H:i:s"))->where('end_date', '>', date("Y-m-d H:i:s"))->get();
        $completed_events = Event::where('end_date', '<', date("Y-m-d H:i:s"))->get();
        return view("events.event_list")->with(["upcoming_events"=>$upcoming_events, "inprogress_events"=>$inprogress_events, "completed_events"=>$completed_events]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($client_id=0)
    {
        if($client_id!=0){
        $employess = Employee::all();
        $consultants = Employee::all();
        $courses = Course::all();
        return view("events.addEvent")->with(["client_id"=>$client_id, "employess"=>$employess, "consultants"=>$consultants, "courses"=>$courses]);
        }    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data["event_name"] = $request->event_name;
        $data["course_id"] = $request->course;
        $data["employees"] = $request->employees;
        $data["client_id"] = $request->client_id;
        $data["start_date"] = $request->start_date;
        $data["end_date"] = $request->end_date;
        $data["consulatant_id"] = $request->consultant;
        $result = Event::insert($data);
        if($result)
        return redirect()->route('events')
            ->with('success','You have successfully add event.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function edit(Event $event)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Event $event)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy($event_id=0)
    {
        $result = Event::where('id', $event_id)->delete();
        if($result)
        return redirect()->back()
            ->with('success','You have successfully deleted event.');
    }
}
